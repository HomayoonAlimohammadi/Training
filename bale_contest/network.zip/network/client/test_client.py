import requests 
from rest_framework import status

###################################################

# headers = {}
# payload = {'username': 'ali'}

# res = requests.post('http://127.0.0.1:8000/register/',
#                     data=payload)

# print(res.status_code)
# print(res.text)

##################################################

# res = requests.get('http://127.0.0.1:8000/list_users')

# print(res.text)
# print(res.json())

##################################################

# headers = {'user_id': '1'}
# payload = {'message': 'new post'}
# res = requests.post('http://127.0.0.1:8000/publish/',
#                     data=payload, headers=headers)

# print(res.status_code)
# print(res.text)

##################################################

# payload = {'username': 'homayoon'}
# res = requests.post('http://127.0.0.1:8000/follow/',
#                     data=payload)

# print(res.status_code)
# print(res.text)

##################################################

# res = requests.get('http://127.0.0.1:8000/get_timeline/')

# print(res.status_code)
# print(res.text)